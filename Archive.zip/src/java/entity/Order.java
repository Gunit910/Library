package entity;

public class Order extends CustomerOrder {

	/**
	 * 
	 */
	public Integer customerId;
	/**
	 * 
	 */
	public Integer amount;
	/**
	 * Getter of customerId
	 */
	public Integer getCustomerId() {
	 	 return customerId; 
	}
	/**
	 * Setter of customerId
	 */
	public void setCustomerId(Integer customerId) { 
		 this.customerId = customerId; 
	}
	
	/**
	 * Setter of amount
	 */
	public void setAmount(Integer amount) { 
		 this.amount = amount; 
	}
	/**
	 * 
	 */
	public void getTotal() { 
		// TODO Auto-generated method
	 } 

}