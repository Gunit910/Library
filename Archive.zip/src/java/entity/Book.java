package entity;
import entity.Category;



class Book extends Category{

	/**
	 * 
	 */
	public Integer price;
	/**
	 * 
	 */
	public Integer bookId;
	/**
	 * 
	 */
	public String title;
	/**
	 * Getter of price
	 */
	public Integer getPrice() {
	 	 return price; 
	}
	/**
	 * Setter of price
	 */
	public void setPrice(Integer price) { 
		 this.price = price; 
	}
	/**
	 * Getter of bookId
	 */
	public Integer getBookId() {
	 	 return bookId; 
	}
	/**
	 * Setter of bookId
	 */
	public void setId(Integer bookId) { 
		 this.bookId = bookId; 
	}
	/**
	 * Getter of title
	 */
	public String getTitle() {
	 	 return title; 
	}
	/**
	 * Setter of title
	 */
	public void setTitle(String title) { 
		 this.title = title; 
	}
	/**
	 * 
	 */
	public void getStatus() { 
		// TODO Auto-generated method
	 } 

}